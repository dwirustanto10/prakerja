alert("Hello world from alert");
confirm("Hello world from confirm");
prompt("Hello world from prompt");